const clouds = document.querySelectorAll(".hole");
const scoreBoard = document.querySelector(".score");
const heads = document.querySelectorAll(".head");

let lastCloud;
let timeUp = false; // False si pas fini, true si fini
let score = 0;

function randomTime(min, max) { // Temps aléatoire
    return Math.round(Math.random() * (max - min) + min);
}

function randomCloud(clouds) { // Selection de nuage aléatoire avec une fonction récursive
    const indexCloud = Math.floor(Math.random() * clouds.length);
    const cloudSelect = clouds[indexCloud];
    if (cloudSelect === lastCloud) { // Pas renvoyer le meme nuage qu'avant
        return randomCloud(clouds);
    }
    lastCloud = cloudSelect;
    return cloudSelect;
}

function showHead() {
    const time = randomTime(1000, 1500); // interval de temps en MS
    const cloud = randomCloud(clouds);
    cloud.classList.add("up"); // .hole.up classe déja existante en CSS. Sert à faire sortir les têtes
    setTimeout(() => {
        if (!timeUp) showHead(); //Fonction récursive
        cloud.classList.remove("up");
    }, time); // exécuter une fonction à partir d'un certain délais
}

function playerScore(event) { // test de faux click
    if (this.classList.contains("up")) {
        score++; // augmenter le score
        this.classList.remove("up");
        scoreBoard.textContent = score;
    };
}
clouds.forEach(head => head.addEventListener("click", playerScore));

function startGame() {
    scoreBoard.textContent = 0;
    socre = 0;
    timeUp = false;
    showHead();
    setTimeout(() => {
        timeUp = true; // condition d'arret du jeu
        setTimeout(() => {
            scoreBoard.textContent = "end";
        }, 2000);
    }, 10000);
}
startGame();